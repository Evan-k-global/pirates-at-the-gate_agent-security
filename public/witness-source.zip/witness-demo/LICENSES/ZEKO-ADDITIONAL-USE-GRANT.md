# Zeko Additional Use Grant

This Zeko Additional Use Grant applies to the Licensed Work identified as
subject to the Business Source License 1.1 and this Additional Use Grant.

## 1. Additional Free Uses

In addition to the non-production rights granted under the Business Source
License 1.1, Zeko Labs grants you the right to use, copy, modify, distribute,
and operate the Licensed Work for the following purposes:

1. Development, testing, benchmarking, research, education, security review,
   audit, internal evaluation, demonstrations, hackathons, local deployments,
   devnet deployments, testnet deployments, staging deployments, and
   proof-of-concept deployments.
2. Building, deploying, operating, or interacting with applications, zkApps,
   agents, wallets, indexers, relayers, dashboards, clients, contracts, bridges,
   SDKs, adapters, connectors, workflows, or settlement integrations that submit
   to, interoperate with, or otherwise use the Official Zeko Network or an
   Official Agent Protocol Deployment.
3. Commercially operating applications, agents, workflows, or integrations that
   use the Official Zeko Network or an Official Agent Protocol Deployment,
   provided that you do not operate an Independent Production Deployment of the
   Licensed Work or an Independent Agent Protocol Deployment.
4. Operating infrastructure as an authorized participant, operator, prover,
   sequencer, validator, relayer, settlement operator, or service provider for
   the Official Zeko Network, where such role has been approved, authorized, or
   designated by Zeko Labs or the applicable Zeko governance process.
5. Using official hosted or public Zeko applications, services, APIs, relays,
   facilitators, verifiers, marketplaces, payment rails, authorization rails,
   coordination rails, or settlement endpoints powered by an Official Agent
   Protocol Deployment.
6. Using any file, package, directory, SDK, specification, example, interface,
   ABI, documentation, test vector, or template that is expressly marked as
   licensed under Apache-2.0, MIT, or another permissive license, subject to
   that separate license.

These Additional Free Uses do not waive ordinary network, gas, transaction,
bridge, prover, marketplace, service, or usage fees charged by the Official
Zeko Network or Official Agent Protocol Deployments. They only clarify that no
separate commercial deployment license is required for that official-network or
official-service use.

## 2. Commercial Deployment License Required

Except as expressly permitted above, the following production deployments are
covered by the self-serve commercial deployment license:

1. an Independent Production Deployment of the Zeko protocol layer;
2. an Independent Agent Protocol Bundle production deployment; or
3. any other production deployment of protected protocol/product-layer code that
   is not covered by the Additional Free Uses above.

The current published self-serve fee is $0/year, subject to the pricing
schedule in `PRICING.md`.

Commercial deployment fees, if any, are payable to Zeko Labs, Inc. or its
successor or assigns. Current self-serve pricing is published in `PRICING.md`
and may be changed by a successor pricing schedule or written authorization.
For payment, billing, commercial licensing, ecosystem agreements, or other
inquiries, contact partnerships@zeko.io.

## 3. Definitions

### Official Zeko Network

Official Zeko Network means any Zeko network, rollup lane, prover network,
sequencer network, settlement endpoint, bridge, or related infrastructure
operated by Zeko Labs, authorized by Zeko Labs, or designated by the applicable
Zeko governance process as part of the official Zeko ecosystem.

### Independent Production Deployment

Independent Production Deployment means a production deployment or operation of
the Licensed Work, or a modified version or derivative work of the Licensed
Work, outside the Official Zeko Network.

Independent Production Deployments include production rollups, sovereign
rollups, appchains, L2s, L3s, sequencer networks, prover networks, settlement
networks, hosted proof services, bridges, protocol deployments, or substantially
similar production infrastructure using protected Zeko protocol-layer code.

### Agent Protocol Bundle

Agent Protocol Bundle means the protected Zeko product/protocol components for
agent-native coordination, authorization, payments, and commerce, including
SantaClawz, ZK x402, Mission-Bound Auth, Magic City when designated by Zeko
Labs, and related protected orchestration, verifier, authorization, payment,
settlement, coordination, marketplace, relay, facilitator, application, API, and
service components.

### Official Agent Protocol Deployment

Official Agent Protocol Deployment means any Agent Protocol Bundle deployment,
hosted service, application, API, relay, verifier, facilitator, marketplace,
authorization layer, payment layer, coordination layer, settlement endpoint, or
related infrastructure operated by Zeko Labs, authorized by Zeko Labs, or
designated by the applicable Zeko governance process as part of the official
Zeko ecosystem.

### Independent Agent Protocol Deployment

Independent Agent Protocol Deployment means a production deployment or operation
of one or more protected Agent Protocol Bundle components, or modified versions
or derivative works of those components, by or on behalf of a legal entity on a
Deployment Network, outside an Official Agent Protocol Deployment.

The Agent Protocol Bundle fee applies only to production deployment or operation
of protected Agent Protocol Bundle code, or modified versions or derivative
works of that code, outside an Official Agent Protocol Deployment. It does not
apply to use of official Zeko-operated or Zeko-authorized applications,
services, APIs, relays, facilitators, verifiers, marketplaces, payment rails,
authorization rails, coordination rails, or settlement endpoints. It also does
not apply to independently developed implementations that do not copy, modify,
derive from, or substantially incorporate protected Agent Protocol Bundle code,
even if they implement similar concepts, protocols, or workflows.

### Deployment Network

Deployment Network means any L1, L2, L3, sovereign rollup, appchain,
application-specific chain, private or permissioned network, synchronizer,
domain, settlement environment, execution environment, or substantially similar
production execution or settlement environment.

### Production

Production means deployment or operation on mainnet or in any
production-equivalent environment involving real users, customer workflows, real
assets, payment activity, revenue-generating activity, external third-party
use, or production settlement.

A deployment is not non-production merely because it is labeled "testnet,"
"pilot," "beta," "sandbox," "staging," or "proof of concept." A deployment is
production if it uses, controls, settles, routes, verifies, authorizes, gates
access to, or materially affects real assets, real payments, customer
workflows, paid services, external users, or mainnet state on any Deployment
Network.

### Non-Production

Non-Production means local, devnet, testnet, staging, internal evaluation,
research, audit, educational, demo, hackathon, or proof-of-concept use that
does not involve real assets, customer workflows, paid services, external
production users, or material interaction with mainnet state.

## 4. No Trademark Rights

This Additional Use Grant does not grant any right to use the names, logos, or
trademarks of Zeko Labs, Zeko, SantaClawz, Magic City, or any related brand,
except as separately authorized in writing.

## 5. Separate Commercial Services

The self-serve commercial deployment license covers license rights only.
Managed deployment, enterprise support, compliance review, SLAs, custom
integrations, dedicated infrastructure, hosted services, and professional
services are separate commercial services.

## 6. Separate Licenses Control

If a file, package, directory, or component contains a separate license notice,
that notice controls for that file, package, directory, or component.

